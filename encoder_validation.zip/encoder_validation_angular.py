import rosbag
import numpy as np
import matplotlib.pyplot as plt

def yaw_from_quat(q):
    return np.arctan2(2.0*(q.w*q.z+q.x*q.y), 1.0 - 2.0*(q.y*q.y + q.z*q.z))

# bag = rosbag.Bag('bags/2024-03-14-10-56-14.bag')
bag = rosbag.Bag('bags/2024-03-14-14-13-13.bag')
# print(bag.get_type_and_topic_info())
encoder_pos = [((msg.right_ticks - msg.left_ticks), time.to_time()) for _, msg, time in bag.read_messages(topics=['/lli/encoder'])]
encoder_vel = [((msg.right_ticks - msg.left_ticks) / msg.right_time_delta / 1.0e-6, time.to_time()) for _, msg, time in bag.read_messages(topics=['/lli/encoder'])]
mocap_pos = [(msg.pose.orientation, time.to_time()) for _, msg, time in bag.read_messages(topics=['/qualisys/svea3/pose'])]
mocap_vel = [(msg.twist.angular, time.to_time()) for _, msg, time in bag.read_messages(topics=['/qualisys/svea3/velocity'])]
bag.close()


AXLE_LENGTH = 199.0e-3
ENC_TICKS = 80
TIRE_RADIUS = 0.051
enc_time = [time for _,time in encoder_vel]
encoder_pos = [data * 2 * np.pi * TIRE_RADIUS / ENC_TICKS / AXLE_LENGTH for data,_ in encoder_pos]
for i in range(len(encoder_pos))[1:]:
    encoder_pos[i] += encoder_pos[i-1]
    encoder_pos[i] = encoder_pos[i] - np.sign(encoder_pos[i])*2*np.pi if abs(encoder_pos[i]) >= np.pi else encoder_pos[i]
encoder_vel = [data * 2 * np.pi * TIRE_RADIUS / ENC_TICKS / AXLE_LENGTH for data,_ in encoder_vel]

mocap_pos_time = [time for _,time in mocap_pos]
start = yaw_from_quat(mocap_pos[0][0])
mocap_pos = [yaw_from_quat(data) - start for data,_ in mocap_pos]

mocap_vel_time = [time for _,time in mocap_vel]
mocap_vel = [data.z for data,_ in mocap_vel]


## Plot positions
plt.plot(enc_time, encoder_pos)
plt.plot(mocap_pos_time, mocap_pos)
plt.legend(['encoder distance', 'MOCAP distance'])
plt.show()


## Plot velocities
N = 20
plt.plot(enc_time, encoder_vel)
plt.plot(enc_time, np.convolve(encoder_vel, np.ones(N)/N, mode='same'))
plt.plot(mocap_vel_time, mocap_vel)
plt.legend(['Encoder velocity', 'Encoder velocity (20-MA)', 'MOCAP velocity'])
plt.show()

## Plot time between samples
enc_ts = [t-enc_time[i - 1] for i, t in enumerate(enc_time)][1:]
mocap_pos_ts = [t-mocap_pos_time[i - 1] for i, t in enumerate(mocap_pos_time)][1:]
mocap_vel_ts = [t-mocap_vel_time[i - 1] for i, t in enumerate(mocap_vel_time)][1:]

plt.plot(enc_ts)
plt.legend(['encoder time between samples'])
plt.show()
plt.plot(mocap_pos_ts)
plt.plot(mocap_vel_ts)
plt.legend(['mocap pose time between samples', 'mocap velocity time between samples'])
plt.show()
