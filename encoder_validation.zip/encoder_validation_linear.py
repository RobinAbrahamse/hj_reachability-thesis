import rosbag
import numpy as np
import matplotlib.pyplot as plt

def euclid(msg):
    return (msg.x**2 + msg.y**2 + msg.z**2)**0.5

def minus(this, that):
    this.x -= that[0]
    this.y -= that[1]
    this.z -= that[2]

bag = rosbag.Bag('bags/2024-03-12-17-04-46.bag')
# print(bag.get_type_and_topic_info())
encoder_pos = [((msg.right_ticks + msg.left_ticks) / 2.0, time.to_time()) for _, msg, time in bag.read_messages(topics=['/lli/encoder'])]
encoder_vel = [((msg.right_ticks + msg.left_ticks) / 2.0 / msg.right_time_delta / 1e-6, time.to_time()) for _, msg, time in bag.read_messages(topics=['/lli/encoder'])]
mocap_pos = [(msg.pose.position, time.to_time()) for _, msg, time in bag.read_messages(topics=['/qualisys/svea3/pose'])]
mocap_vel = [(msg.twist.linear, time.to_time()) for _, msg, time in bag.read_messages(topics=['/qualisys/svea3/velocity'])]
bag.close()

ENC_TICKS = 80
TIRE_RADIUS = 0.051
enc_time = [time for _,time in encoder_vel]
encoder_pos = [data * 2 * np.pi * TIRE_RADIUS / ENC_TICKS for data,_ in encoder_pos]
for i in range(len(encoder_pos))[1:]:
    encoder_pos[i] += encoder_pos[i-1]
encoder_vel = [data * 2 * np.pi * TIRE_RADIUS / ENC_TICKS for data,_ in encoder_vel]

mocap_pos_time = [time for _,time in mocap_pos]
start = (mocap_pos[0][0].x, mocap_pos[0][0].y, mocap_pos[0][0].z)
mid = (mocap_pos[1850][0].x, mocap_pos[1850][0].y, mocap_pos[1850][0].z)
[minus(data, start) for data,_ in mocap_pos[:1850]]
[minus(data, mid) for data,_ in mocap_pos[1850:]]
mocap_pos = [euclid(data) for data,_ in mocap_pos]
mocap_pos[1850:] = [data + mocap_pos[1849] for data in mocap_pos[1850:]]

mocap_vel_time = [time for _,time in mocap_vel]
mocap_vel = [abs(data.x) for data,_ in mocap_vel]


## Plot positions
plt.plot(enc_time, encoder_pos)
plt.plot(mocap_pos_time, mocap_pos)
plt.legend(['encoder distance', 'MOCAP distance'])
plt.show()


## Plot velocities
N = 20
plt.plot(enc_time, encoder_vel)
plt.plot(enc_time, np.convolve(encoder_vel, np.ones(N)/N, mode='same'))
plt.plot(mocap_vel_time, mocap_vel)
plt.legend(['Encoder velocity', 'Encoder velocity (20-MA)', 'MOCAP velocity'])
plt.show()

## Plot time between samples
enc_ts = [t-enc_time[i - 1] for i, t in enumerate(enc_time)][1:]
mocap_pos_ts = [t-mocap_pos_time[i - 1] for i, t in enumerate(mocap_pos_time)][1:]
mocap_vel_ts = [t-mocap_vel_time[i - 1] for i, t in enumerate(mocap_vel_time)][1:]

plt.plot(enc_ts)
plt.legend(['encoder time between samples'])
plt.show()
plt.plot(mocap_pos_ts)
plt.plot(mocap_vel_ts)
plt.legend(['mocap pose time between samples', 'mocap velocity time between samples'])
plt.show()
